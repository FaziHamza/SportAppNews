import { Component } from '@angular/core';

@Component({
  selector: 'app-sub',
  standalone: true,
  imports: [],
  templateUrl: './sub.component.html',
  styleUrl: './sub.component.scss'
})
export class SubComponent {

}
