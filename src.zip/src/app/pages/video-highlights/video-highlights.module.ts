import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/modules/shared.module';

@NgModule({
  declarations: [],
  imports: [
    SharedModule,
  ],
  exports: [
    SharedModule,
  ]
})
export class VideoHighlightsModule { }
