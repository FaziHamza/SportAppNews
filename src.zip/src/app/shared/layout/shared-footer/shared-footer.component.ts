import { Component } from '@angular/core';

@Component({
  selector: 'app-shared-footer',
  standalone: true,
  imports: [],
  templateUrl: './shared-footer.component.html',
  styleUrl: './shared-footer.component.scss'
})
export class SharedFooterComponent {

}
